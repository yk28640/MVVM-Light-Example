﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CustomControlDev
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //Valve01.FillBinding = Brushes.Red;
            Valve01.Status_Opened = !Valve01.Status_Opened;

           Thread taskThread = new Thread(DoTask);
           taskThread.Start();

          
        }
        private void DoTask()
        {
            Random rd = new Random();
            Int64 InputNum = (Int64)1000;
            for (Int64 i = 0; i < InputNum; i++)
            {
                Thread.Sleep(1000);
                this.Dispatcher.BeginInvoke((Action)delegate ()
                {
                    Valve01.BarBinding = rd.Next(100);
                });
            }
        }
            private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Valve01.Status_Closed = !Valve01.Status_Closed;
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Valve01.Status_Alarm = !Valve01.Status_Alarm;
        }
    }
}
